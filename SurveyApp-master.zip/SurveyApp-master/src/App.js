import React, { Component } from 'react';
import './App.css';
import FullResult from './FullResult';

class App extends Component {
  render() {
    return (
        <div className="App">
          <FullResult />
        </div>
    );
  }
}

export default App;
